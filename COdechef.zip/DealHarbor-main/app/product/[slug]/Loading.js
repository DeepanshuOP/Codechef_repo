import Preloader from "../../../components/Preloader"
import React from 'react';

const Loading = () => {
    return (
        
        <Preloader />
        
    );
}

export default Loading;
