import React from 'react';
import Preloader from '../components/Preloader';

const Loading = () => {
  return <Preloader />;
};

export default Loading;
